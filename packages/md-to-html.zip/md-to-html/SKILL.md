---
name: md-to-html
description: |
  将 Markdown 或 Obsidian 笔记忠实发布为精美、独立、响应式 HTML，不重新分析、摘要或改写正文。支持 YAML 元数据、Obsidian callout、Wikilink 可读降级、KaTeX 公式、Mermaid、表格、代码块和本地图片嵌入。用于用户提出“MD 转 HTML”“生成网页阅读版”“发布 Markdown”“刷新 HTML”或 paper-analyzer 明确需要同时输出 HTML 的场景。
---

# Markdown to HTML

把 Markdown 视为唯一事实来源，只执行确定性发布。

## 工作流

1. 读取输入 Markdown，确认它是用户指定的主稿。
2. 确定输出：
   - 默认：与 Markdown 同目录、同 stem 的 `.html`。
   - 用户指定路径时采用指定路径。
   - 输出已存在时默认停止；只有用户明确要求“刷新、更新、覆盖”时使用 `--force`。
3. 运行转换脚本：

```bash
python3 scripts/convert.py "/absolute/path/note.md"
python3 scripts/convert.py "/absolute/path/note.md" --output "/absolute/path/note.html"
python3 scripts/convert.py "/absolute/path/note.md" --force
```

4. 阅读脚本输出的 JSON 报告，说明：
   - 输出路径与生成时间；
   - 标题、章节、表格、代码块、公式和 Mermaid 数量；
   - 嵌入图片数量；
   - 降级为可读文本的 Wikilink 目标。
5. 使用本地浏览器检查桌面端和 `390 × 844` 移动端：
   - 标题、正文、表格、代码、公式和 Mermaid 已显示；
   - KaTeX 与 Mermaid 无控制台错误；
   - `document.documentElement.scrollWidth <= clientWidth`；
   - 临时移动端 viewport 在结束前恢复。

## 忠实转换规则

- 不增删、摘要、润色或重排正文论点。
- YAML 不作为正文重复展示；选取标题、作者、年份、会议、来源和审核状态形成元信息卡。
- Obsidian callout 转为语义化提示框并保留标题与正文。
- `$...$`、`$$...$$` 交给 KaTeX；`mermaid` fenced block 转为 Mermaid 图。
- 普通代码块保持语言标记；表格允许在窄屏内部横向滚动。
- 相对或绝对本地图片嵌入为 data URI，使 HTML 可单文件携带；远程图片保留原 URL。
- Wikilink 显示别名或目标名，但不伪造可分享链接；在报告中列为 `wikilinks_as_text`。
- HTML 顶部必须显示生成时间、源 Markdown 路径和“请编辑 Markdown 主稿”的提示。

## 安全与写入

- 不静默覆盖现有 HTML。
- 不修改输入 Markdown。
- 不创建额外报告文件；报告只写到标准输出。
- 不把本地笔记或图片发送到外部服务。KaTeX 与 Mermaid 运行库由生成页面在打开时从 CDN 加载。
- 若用户要求完全离线 HTML，先说明当前模板的运行库依赖 CDN，再单独处理资源内嵌。

## 依赖

- Python 3 标准库。
- Pandoc，可通过 `pandoc` 命令发现。
- `assets/academic-template.html`。

若 Pandoc 不可用，停止并报告，不使用会丢失结构的简化正则转换。
