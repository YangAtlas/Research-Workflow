#!/usr/bin/env python3
"""Publish Markdown/Obsidian notes as standalone, responsive HTML."""

from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import html
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from urllib.parse import unquote, urlparse


FENCE_RE = re.compile(r"(?ms)^```([^\n]*)\n(.*?)^```\s*$")
WIKI_EMBED_RE = re.compile(r"!\[\[([^\]|]+)(?:\|([^\]]+))?\]\]")
WIKI_LINK_RE = re.compile(r"(?<!!)\[\[([^\]|]+)(?:\|([^\]]+))?\]\]")
IMAGE_TAG_RE = re.compile(r"<img\b[^>]*?\bsrc=(['\"])(.*?)\1[^>]*>", re.I)
CALLOUT_RE = re.compile(r"^\[!([A-Za-z0-9_-]+)\](?:[+-])?\s*(.*)$")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Convert Markdown to standalone academic HTML without rewriting content."
    )
    parser.add_argument("input", type=Path, help="Source Markdown file")
    parser.add_argument("--output", type=Path, help="Output HTML; defaults beside input")
    parser.add_argument(
        "--force", action="store_true", help="Replace an existing output HTML"
    )
    return parser.parse_args()


def split_frontmatter(text: str) -> tuple[str, str]:
    if not text.startswith("---\n"):
        return "", text
    end = text.find("\n---\n", 4)
    if end < 0:
        return "", text
    return text[4:end], text[end + 5 :]


def clean_yaml_scalar(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        value = value[1:-1]
    if value in {"", "null", "Null", "NULL", "~"}:
        return ""
    return value


def parse_simple_frontmatter(raw: str) -> dict[str, object]:
    """Parse the flat scalars and top-level lists used by research notes."""
    data: dict[str, object] = {}
    current: str | None = None
    for line in raw.splitlines():
        item = re.match(r"^\s{2,}-\s+(.*)$", line)
        if item and current:
            if data.get(current) == "":
                data[current] = []
            values = data.setdefault(current, [])
            if isinstance(values, list):
                values.append(clean_yaml_scalar(item.group(1)))
            continue
        field = re.match(r"^([A-Za-z0-9_-]+):\s*(.*)$", line)
        if field:
            current = field.group(1)
            value = clean_yaml_scalar(field.group(2))
            data[current] = value
        elif line and not line[0].isspace():
            current = None
    return data


def protect_fences(text: str) -> tuple[str, dict[str, str], int, int]:
    protected: dict[str, str] = {}
    mermaid_count = 0
    code_count = 0

    def replace(match: re.Match[str]) -> str:
        nonlocal mermaid_count, code_count
        info = match.group(1).strip()
        body = match.group(2)
        token = f"@@MDHTML_BLOCK_{len(protected)}@@"
        if info and info.split(maxsplit=1)[0].lower() == "mermaid":
            mermaid_count += 1
            protected[token] = (
                '<pre class="mermaid">' + html.escape(body.rstrip()) + "</pre>"
            )
        else:
            code_count += 1
            protected[token] = match.group(0)
        return token

    return FENCE_RE.sub(replace, text), protected, mermaid_count, code_count


def restore_fences(text: str, protected: dict[str, str]) -> str:
    for token, block in protected.items():
        text = text.replace(token, block)
    return text


def transform_callouts(text: str) -> tuple[str, int]:
    lines = text.splitlines()
    output: list[str] = []
    callout_count = 0
    index = 0
    while index < len(lines):
        if not lines[index].startswith(">"):
            output.append(lines[index])
            index += 1
            continue

        quoted: list[str] = []
        start = index
        while index < len(lines) and lines[index].startswith(">"):
            quoted.append(re.sub(r"^>\s?", "", lines[index]))
            index += 1

        if quoted:
            match = CALLOUT_RE.match(quoted[0])
            if match:
                kind = match.group(1).lower()
                title = match.group(2).strip() or kind.replace("-", " ").title()
                output.extend(
                    [
                        f'::: {{.callout .callout-{kind}}}',
                        f'<div class="callout-title">{html.escape(title)}</div>',
                        "",
                        *quoted[1:],
                        ":::",
                    ]
                )
                callout_count += 1
                continue

        output.extend(lines[start:index])
    return "\n".join(output), callout_count


def transform_wikilinks(text: str) -> tuple[str, list[str]]:
    targets: list[str] = []

    def embed(match: re.Match[str]) -> str:
        target = match.group(1).strip()
        alias = (match.group(2) or "").strip()
        suffix = Path(target.split("#", 1)[0]).suffix.lower()
        if suffix in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg"}:
            alt = alias if alias and not alias.isdigit() else Path(target).stem
            return f"![{alt}]({target})"
        targets.append(target)
        label = alias or Path(target).name
        return (
            f'<span class="wikilink embed-unavailable" '
            f'data-target="{html.escape(target, quote=True)}">'
            f"{html.escape(label)}</span>"
        )

    def link(match: re.Match[str]) -> str:
        target = match.group(1).strip()
        alias = (match.group(2) or "").strip()
        targets.append(target)
        label = alias or target.split("#", 1)[0]
        return (
            f'<span class="wikilink" data-target="{html.escape(target, quote=True)}">'
            f"{html.escape(label)}</span>"
        )

    text = WIKI_EMBED_RE.sub(embed, text)
    text = WIKI_LINK_RE.sub(link, text)
    return text, sorted(set(targets))


def extract_title(body: str, metadata: dict[str, object], fallback: str) -> str:
    value = metadata.get("title")
    if isinstance(value, str) and value:
        return value
    match = re.search(r"(?m)^#\s+(.+?)\s*$", body)
    return match.group(1).strip() if match else fallback


def render_metadata(metadata: dict[str, object]) -> str:
    fields = [
        ("authors", "作者"),
        ("published", "年份"),
        ("year", "年份"),
        ("venue", "会议/期刊"),
        ("doi", "DOI"),
        ("url", "论文链接"),
        ("code_url", "代码"),
        ("review_status", "审核状态"),
    ]
    rows: list[str] = []
    seen_labels: set[str] = set()
    for key, label in fields:
        value = metadata.get(key)
        if label in seen_labels or value is None or value == "" or value == []:
            continue
        seen_labels.add(label)
        if isinstance(value, list):
            shown = ", ".join(str(item) for item in value if item)
        else:
            shown = str(value)
        if not shown:
            continue
        if key in {"url", "code_url"} and shown.startswith(("http://", "https://")):
            rendered = (
                f'<a href="{html.escape(shown, quote=True)}">'
                f"{html.escape(shown)}</a>"
            )
        else:
            rendered = html.escape(shown)
        rows.append(
            f"<dt>{html.escape(label)}</dt><dd>{rendered}</dd>"
        )
    if not rows:
        return ""
    return '<dl class="paper-meta">' + "".join(rows) + "</dl>"


def run_pandoc(markdown_text: str) -> str:
    pandoc = shutil.which("pandoc")
    if not pandoc:
        raise RuntimeError("Pandoc is required but was not found on PATH.")
    result = subprocess.run(
        [
            pandoc,
            "--from=markdown+fenced_divs+raw_html+tex_math_dollars+pipe_tables+task_lists",
            "--to=html5",
            "--mathjax",
            "--wrap=none",
        ],
        input=markdown_text,
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or "Pandoc conversion failed.")
    return result.stdout


def local_image_path(src: str, base_dir: Path) -> Path | None:
    parsed = urlparse(html.unescape(src))
    if parsed.scheme in {"http", "https", "data"}:
        return None
    if parsed.scheme == "file":
        candidate = Path(unquote(parsed.path))
    elif parsed.scheme:
        return None
    else:
        raw_path = unquote(parsed.path)
        candidate = Path(raw_path)
        if not candidate.is_absolute():
            candidate = base_dir / candidate
    try:
        return candidate.resolve()
    except OSError:
        return candidate


def embed_local_images(fragment: str, base_dir: Path) -> tuple[str, int, list[str]]:
    embedded = 0
    missing: list[str] = []

    def replace(match: re.Match[str]) -> str:
        nonlocal embedded
        src = match.group(2)
        path = local_image_path(src, base_dir)
        if path is None:
            return match.group(0)
        if not path.is_file():
            missing.append(src)
            return match.group(0)
        mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        payload = base64.b64encode(path.read_bytes()).decode("ascii")
        replacement = f"data:{mime};base64,{payload}"
        embedded += 1
        start, end = match.span(2)
        relative_start = start - match.start()
        relative_end = end - match.start()
        tag = match.group(0)
        return tag[:relative_start] + replacement + tag[relative_end:]

    return IMAGE_TAG_RE.sub(replace, fragment), embedded, sorted(set(missing))


def count_source(body: str) -> dict[str, int]:
    return {
        "headings": len(re.findall(r"(?m)^#{1,6}\s+", body)),
        "tables": len(
            re.findall(r"(?m)^\s*\|(?:\s*:?-{3,}:?\s*\|)+\s*$", body)
        ),
        "formulas": len(re.findall(r"\$\$[\s\S]*?\$\$|(?<!\$)\$(?!\$).+?(?<!\$)\$(?!\$)", body)),
        "images": len(re.findall(r"!\[[^\]]*\]\([^)]+\)|!\[\[[^\]]+\]\]", body)),
    }


def main() -> int:
    args = parse_args()
    source = args.input.expanduser().resolve()
    output = (
        args.output.expanduser().resolve()
        if args.output
        else source.with_suffix(".html")
    )
    if not source.is_file():
        print(json.dumps({"error": f"Markdown not found: {source}"}, ensure_ascii=False))
        return 2
    if source.suffix.lower() not in {".md", ".markdown"}:
        print(json.dumps({"error": "Input must be .md or .markdown"}, ensure_ascii=False))
        return 2
    if source == output:
        print(json.dumps({"error": "Input and output paths must differ."}, ensure_ascii=False))
        return 2
    if output.exists() and not args.force:
        print(
            json.dumps(
                {
                    "error": "Output already exists; pass --force only after explicit approval.",
                    "output": str(output),
                },
                ensure_ascii=False,
            )
        )
        return 3

    raw = source.read_text(encoding="utf-8")
    frontmatter_raw, body = split_frontmatter(raw)
    metadata = parse_simple_frontmatter(frontmatter_raw)
    title = extract_title(body, metadata, source.stem)
    protected_text, protected, mermaid_count, code_count = protect_fences(body)
    callout_text, callout_count = transform_callouts(protected_text)
    wiki_text, wikilinks = transform_wikilinks(callout_text)
    prepared = restore_fences(wiki_text, protected)
    fragment = run_pandoc(prepared)
    fragment, embedded_count, missing_images = embed_local_images(
        fragment, source.parent
    )

    template_path = Path(__file__).resolve().parent.parent / "assets" / "academic-template.html"
    if not template_path.is_file():
        raise RuntimeError(f"Template not found: {template_path}")
    template = template_path.read_text(encoding="utf-8")
    generated_at = dt.datetime.now().astimezone().isoformat(timespec="seconds")
    source_hash = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    document = (
        template.replace("{{TITLE}}", html.escape(title))
        .replace("{{SOURCE_PATH}}", html.escape(str(source)))
        .replace("{{GENERATED_AT}}", html.escape(generated_at))
        .replace("{{SOURCE_SHA256}}", source_hash)
        .replace("{{METADATA}}", render_metadata(metadata))
        .replace("{{CONTENT}}", fragment)
    )

    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{output.name}.", suffix=".tmp", dir=output.parent
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(document)
        os.replace(temp_name, output)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)

    source_counts = count_source(body)
    report = {
        "input": str(source),
        "output": str(output),
        "generated_at": generated_at,
        "source_sha256": source_hash,
        **source_counts,
        "code_blocks": code_count,
        "mermaid_blocks": mermaid_count,
        "callouts": callout_count,
        "embedded_images": embedded_count,
        "missing_images": missing_images,
        "wikilinks_as_text": wikilinks,
        "bytes": output.stat().st_size,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1)
