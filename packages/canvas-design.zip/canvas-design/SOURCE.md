# 来源与打包信息

- Skill：canvas-design
- 日期：2026-09-27
- 来源：https://github.com/anthropics/skills/tree/main/skills/canvas-design
- 许可：保留 Apache-2.0 LICENSE.txt；字体分别保留 OFL 声明。

## 包内行为

本包保留本地技能内容和配套资源。
