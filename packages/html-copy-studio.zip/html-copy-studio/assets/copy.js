document.querySelectorAll('button[data-copy]').forEach(button=>button.addEventListener('click',async()=>{
 const article=document.getElementById(button.dataset.copy),content=article.querySelector('.'+button.dataset.part),status=article.querySelector('.copy-status');
 const clone=content.cloneNode(true);clone.style.fontFamily='Arial';clone.style.fontSize='18pt';clone.style.color='#182430';
 clone.querySelectorAll('h2').forEach(x=>{x.style.fontSize='26pt';x.style.marginBottom='12pt'});
 clone.querySelectorAll('p,li').forEach(x=>x.style.marginBottom='8pt');
 try{
  if(navigator.clipboard&&window.ClipboardItem){await navigator.clipboard.write([new ClipboardItem({'text/html':new Blob([clone.outerHTML],{type:'text/html'}),'text/plain':new Blob([content.innerText],{type:'text/plain'})})]);}
  else{const selection=getSelection(),range=document.createRange();range.selectNodeContents(content);selection.removeAllRanges();selection.addRange(range);if(!document.execCommand('copy'))throw Error('copy');selection.removeAllRanges();}
  status.textContent='已复制。粘贴时选择“保留源格式”。';
 }catch{
  const selection=getSelection(),range=document.createRange();range.selectNodeContents(content);selection.removeAllRanges();selection.addRange(range);status.textContent='已选中内容，请按 Ctrl+C 复制。';
 }
}));
