---
review_status: pending
---

# HTML 文案工作台示例

这份示例展示逐页文案、更新标色和视觉构思的组织方式。内容为虚构的团队日程产品。蓝色表示相对示例旧稿新增的功能描述。

## Slide 4 — A Shared View of Team Availability

**Plan work around the people available to deliver it**

- **Weekly schedule:** Review assigned work and delivery dates in one place.
- <span style="color:#0066CC">**Team availability:** View available working hours alongside the schedule.</span>
- **Project context:** Open a task to review its owner and expected outcome.
- <span style="color:#0066CC">**Planning support:** Identify scheduling conflicts before confirming the next week’s assignments.</span>

:::visual
### 配图构思

展示一张虚构的周日程示意，突出任务安排与人员可用时间之间的关系。真实产品交付时优先使用用户提供的产品截图。

### 版式示意

<div class="layout-wireframe"><div>左侧约 40%<br>标题与 4 个要点</div><div>右侧约 60%<br>周日程截图位置<br>突出可用时间与冲突提示</div></div>

### 可选插画提示词

An editorial illustration of a small team planning the coming week, with people and a calendar arranged on the right and clean negative space on the left for presentation copy. Calm blue and warm neutral palette, landscape 16:9. No embedded text. The visual should communicate coordination and available time.

当前为构思与版式示意，插画尚未生成。
:::

## Slide 5 — Review and Confirm the Weekly Plan

**A clear sequence for the planning discussion**

| Step | Discussion point | Outcome |
| --- | --- | --- |
| Review | What work is already committed? | A shared list of commitments |
| Coordinate | Who is available to take new work? | Proposed assignments |
| Confirm | Which dates can the team support? | An agreed weekly plan |

:::visual
### 排版建议

本页以表格为主体，占正文宽度约 90%。每行保留一个动作、一个讨论问题和一个结果，方便讲解时逐行推进。
:::

:::appendix
## 编辑说明

示例仅演示文案、表格、局部蓝色和视觉说明的呈现方式。实际任务应替换为有来源的材料。复制文案按钮只复制标题和正文，视觉方案有独立按钮。
