import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';

const args=process.argv.slice(2),opts={};
for(let i=0;i<args.length;i+=2){if(!['--input','--output','--modules-dir'].includes(args[i])||!args[i+1])throw Error('Usage: render.mjs --input copy.md [--output copy.html] [--modules-dir node_modules]');opts[args[i]]=args[i+1];}
if(!opts['--input'])throw Error('--input is required');
const input=path.resolve(opts['--input']);
const output=path.resolve(opts['--output']||input.replace(/\.md$/i,'')+'.html');
if(input===output)throw Error('Output must differ from the Markdown input');
const req=opts['--modules-dir']?createRequire(path.join(path.resolve(opts['--modules-dir']),'__resolver__.cjs')):createRequire(import.meta.url);
const {marked}=await import(pathToFileURL(req.resolve('marked')).href);
const skill=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const esc=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const raw=fs.readFileSync(input,'utf8').replace(/^\uFEFF/,'').replace(/\r\n/g,'\n').replace(/^---\n[\s\S]*?\n---\n/,'');
const split=raw.indexOf('\n:::appendix');
const main=split<0?raw:raw.slice(0,split),appendix=split<0?'':raw.slice(split+'\n:::appendix'.length);
const title=(main.match(/^# (.+)$/m)||[])[1]||path.basename(input,'.md');
const visuals=[];
const body=main.replace(/^:::visual\s*\n([\s\S]*?)^:::\s*$/gm,(_,v)=>`\n<!--visual:${visuals.push(v)-1}-->\n`);
const heads=[...body.matchAll(/^## (.+)$/gm)];
if(!heads.length)throw Error('Add at least one level-two heading for a page or section');
const intro=body.slice(0,heads[0].index).replace(/^# .+$/m,'');
const slides=heads.map((h,i)=>{
 let text=body.slice(h.index+h[0].length,i+1<heads.length?heads[i+1].index:body.length).trim(),design=[];
 text=text.replace(/<!--visual:(\d+)-->/g,(_,n)=>{design.push(visuals[Number(n)]);return '';});
 const match=h[1].match(/^(?:Slide|Page|Section)\s+(\d+)\s*[—:：-]\s*(.+)$/i);
 return {id:`section-${i+1}`,label:match?match[1]:String(i+1),title:match?match[2]:h[1],text,design:design.join('\n\n')};
});
const mime={'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif','.svg':'image/svg+xml'};
let embedded=0;
function render(md){return marked.parse(md).replace(/(<img\b[^>]*\bsrc=")([^"]+)(")/g,(whole,start,src,end)=>{
 if(/^(?:data:|https?:|\/\/)/i.test(src))return whole;
 const decoded=src.replaceAll('&amp;','&');
 const local=decoded.startsWith('file:')?fileURLToPath(decoded):path.resolve(path.dirname(input),decodeURIComponent(decoded));
 const type=mime[path.extname(local).toLowerCase()];
 if(!type)throw Error('Unsupported local image format: '+local);
 if(!fs.existsSync(local))throw Error('Missing local image: '+local);
 embedded++;return start+`data:${type};base64,`+fs.readFileSync(local).toString('base64')+end;
});}
const cards=slides.map(s=>`<article id="${s.id}" class="slide"><header><p class="slide-number">${esc(s.label)}</p><button type="button" data-copy="${s.id}" data-part="copy-content">复制文案</button></header><div class="copy-content"><h2>${esc(s.title)}</h2>${render(s.text)}</div>${s.design?`<aside class="visual-area"><header><h3>配图与版式构思</h3><button type="button" data-copy="${s.id}" data-part="visual-notes">复制视觉方案</button></header><div class="visual-notes">${render(s.design)}</div></aside>`:''}<p class="copy-status" aria-live="polite"></p></article>`).join('\n');
const css=fs.readFileSync(path.join(skill,'assets/style.css'),'utf8');
const js=fs.readFileSync(path.join(skill,'assets/copy.js'),'utf8');
const html=`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>${css}</style></head><body><main><section class="intro"><h1>${esc(title)}</h1>${render(intro)}<p>按页复制文案，粘贴时选择“保留源格式”。视觉构思可单独复制。</p></section><nav aria-label="页面导航">${slides.map(s=>`<a href="#${s.id}" title="${esc(s.title)}">${esc(s.label)}</a>`).join('')}${appendix?'<a href="#editing-notes">编辑说明</a>':''}</nav>${cards}${appendix?`<section class="appendix" id="editing-notes">${render(appendix)}</section>`:''}</main><script>${js}</script></body></html>`;
fs.mkdirSync(path.dirname(output),{recursive:true});fs.writeFileSync(output,html,'utf8');
console.log(JSON.stringify({output,sections:slides.length,visualSections:slides.filter(s=>s.design).length,embeddedImages:embedded}));
