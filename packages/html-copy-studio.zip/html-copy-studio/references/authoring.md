# Markdown 编写约定

## 页面结构

一级标题是阅读版标题，其后的简介说明用途、基线或复制方式。每个二级标题是一页或一节，可以使用实际页码（例如 `## Slide 4 — System Architecture`），也可以直接写章节名。页面内部用加粗引导语、列表、三级标题和表格。

可选 YAML 属性保留在 Markdown，渲染时不显示。最后的 `:::appendix` 独占一行，之后是来源、编辑说明及待复核内容，不进入任何页面的文案复制区。

```markdown
---
review_status: pending
---

# 产品介绍文案

适用于产品沟通会。蓝色表示相对已确认旧稿新增的内容。

## Slide 4 — Scheduling Overview

**A shared view of upcoming work**

- **Current plan:** Review assigned work and delivery dates.
- <span style="color:#0066CC">**Availability:** View team availability alongside the schedule.</span>

:::visual
### 视觉目的

让读者理解任务安排与人员可用时间的对应关系。

### 配图与版式

左侧约 40% 放文案，右侧约 60% 放已提供的日程截图。突出当前周和人员可用时间，保留必要的日期与图例。

### 图片提示词

如需概念插画，可使用：An editorial illustration of a team planning a weekly schedule, with the people on the right and clear negative space on the left. Calm blue palette, landscape 16:9, no embedded text.
:::

## Slide 5 — Next Steps

- Confirm the schedule with the team.

:::appendix
## 来源与编辑说明

填写实际来源，区分待制作图片与已存在的图片。
```

## 视觉区与图片

- `:::visual` 和结束的 `:::` 各自独占一行。内容可含 Markdown 标题、图片、表格或必要的 HTML 版式线框。图片用 `![说明](./assets/image.png)`，相对路径以 Markdown 文件所在目录解析。
- 图片支持 PNG、JPEG、WebP、GIF 和 SVG，本地图片会内嵌成 data URL。图片路径中有空格时使用 `<路径>` 包裹 Markdown 目标。远程图片地址原样保留，生成器不抓取网络资源。
- 线框可以用 `<div class="layout-wireframe"><div>文案区 40%</div><div>图片区 60%</div></div>`。这只展示空间分配，不代表成品画面。
- 图文思路在视觉区单独展示、单独复制。来源和技术核对记录放末尾 appendix。生成器不改变文案含义，也不自动判断更新或蓝色范围。

## 调用与依赖

`render.mjs` 依赖 Node 和 `marked`。优先使用 `load_workspace_dependencies` 返回的 Node 与 node_modules，通过 `--modules-dir` 显式传入。已有正常 Node 包解析环境时可省略该参数。

输入文件名决定默认输出路径；`--output` 可另指定。生成器会覆盖指定 HTML，先遵守用户目录与文件保留约定。源 Markdown不被修改。

输出带页码导航、复制文案/复制视觉方案按钮、图片预览和打印样式。浏览器支持富文本剪贴板时保留蓝色和表格；否则选中文字供手动复制。PowerPoint 粘贴选“保留源格式”，然后适配目标文本框的字号。具体成品 PPTX 的容纳情况仍需在幻灯片中检查。
