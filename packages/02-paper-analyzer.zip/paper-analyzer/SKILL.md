---
name: paper-analyzer
description: |
  将学术论文转化为可长期维护的深度 Markdown 研究笔记。执行全文阅读、开源代码检索、公式与图表解析、实验审计和局限分析，支持 academic、storytelling、concise 三种写作风格。默认只生成适合 Obsidian 与 AI 后续检索编辑的 Markdown；仅当用户明确要求 HTML、网页、可分享阅读版或“同时生成 HTML”时，再调用 md-to-html 从主稿发布 HTML。
---

# Paper Analyzer — 学术论文深度解析

把论文解析为“可修改、可检索、可追溯”的 Markdown 主稿。Markdown 是唯一事实来源；HTML 只是按需生成的发布产物。

## 输出原则

- 默认只创建或更新一个 `.md` 文件，不自动生成 HTML。
- 用户明确要求“同时生成 HTML”时，先完成 Markdown，再调用 `$md-to-html` 忠实转换；不要重新分析或重写正文。
- 后续补充、纠错和扩展只修改 Markdown。刷新 HTML 时从最新 Markdown 重新生成。
- 新稿必须使用 `review_status: pending`；不得替用户标记为 `verified`。
- 不覆盖已有笔记。若目标文件已存在，先读取并做增量更新；无法安全合并时使用新文件名并说明。

## 快速使用

```text
$paper-analyzer academic 中文 /path/to/paper.pdf
$paper-analyzer storytelling https://arxiv.org/abs/xxxx.xxxxx
$paper-analyzer concise 中文 <论文文本>
$paper-analyzer academic 中文 /path/to/paper.pdf，同时生成 HTML
```

## 六轮强制工作流

### Round 1：获取论文全文

| 输入 | 执行 |
|---|---|
| arXiv URL | 同时读取摘要页与全文 HTML；必要时读取 PDF |
| PDF 路径 | 使用 PDF 工具分段读取全部页面，并检查图表页 |
| 文本 | 使用全部文本，确认没有被截断 |

记录论文标题、作者、年份、会议或期刊、DOI/URL、本地 PDF 路径和页数。标准编号、性能数字、代码状态必须核对原始来源。

### Round 2：检索开源代码

1. 从论文正文、脚注、附录和项目页提取仓库链接。
2. 未提供链接时，用论文标题和作者检索官方仓库。
3. 找到仓库后克隆到唯一的临时目录，记录 URL 与提交哈希。
4. 阅读 README、核心源码和配置，建立论文模块到代码文件/函数的对应。

按状态写入主稿：

| 状态 | 主稿要求 |
|---|---|
| 已发布 | 至少给出 2 处论文方法与源码对应，代码片段不超过 30 行，标注路径和行号 |
| 待发布 | 标注 README/Release 的原始状态与链接 |
| 无代码 | 明确写“未发现官方实现”；相关项目必须标为替代或底层依赖，不得冒充论文代码 |

### Round 3：深度分析

内部完成以下判断，不展示推理过程：

1. 提炼 1–3 个核心创新。
2. 对每个创新梳理输入、处理、输出、有效原因与已有方法差异。
3. 选择最有说服力的实验并解释数字的含义。
4. 区分作者自述局限与独立判断。
5. 识别复现所需但论文或代码未公开的工程细节。

### Round 4：确定语言与风格

- 用户已给出语言或风格时直接采用，不重复询问。
- 未给风格时使用 `academic`。
- 未给语言时沿用用户语言。
- 读取相应的 `styles/<style>.md`；涉及公式或代码时再读取 `styles/with-formulas.md`、`styles/with-code.md`。

### Round 5：写作 Markdown 主稿

在研究库中遵循仓库路由规则；没有明确位置时写入 `01_Inbox`。论文笔记使用以下 YAML：

```yaml
---
type: paper
status: reading
area:
project:
created: YYYY-MM-DD
updated: YYYY-MM-DD
title: "论文标题"
authors:
  - Author One
published:
venue:
doi:
url:
source: local_pdf
pdf_source: "/absolute/path/to/paper.pdf"
code_url:
code_commit:
keywords: []
review_status: pending
---
```

正文按风格组织，但必须包含：

1. 一句话总结。
2. 论文元信息与来源。
3. 研究背景和可证伪问题。
4. 核心方法、公式及“人话解释”。
5. Figure/Table/Section 编号对应。
6. 实验设置、数据表和结果解读。
7. 代码状态与论文—源码对应。
8. 作者结论、AI 独立分析、局限和复现边界。
9. 证据来源与待人工复核项。

使用 Obsidian 原生结构：

```markdown
> [!quote] 论文结论
> 只放论文可以直接支持的陈述。

> [!analysis] AI 独立分析
> 明确标记外推、质疑或研究启示。

> [!warning] 复现边界
> 标记缺失代码、数据、配置或硬件条件。
```

- 公式保留为 `$...$` 或 `$$...$$`。
- 架构图保留为 fenced `mermaid` 代码块。
- 代码使用带语言标记的 fenced code block，并在前后标注文件路径和行号。
- 不在 Markdown 中嵌入网页专用 `<style>`、KaTeX CDN 或 Mermaid 脚本。

若用户明确要求 HTML：

1. 先保存并自检 Markdown。
2. 加载 `$md-to-html`。
3. 默认生成同目录同 stem 的 `.html`。
4. 已存在 HTML 时，只有用户明确要求刷新或覆盖才允许替换。

### Round 6：自我审查

检查并修正：

- YAML 可解析，`review_status: pending`，来源路径和链接存在或已标注不可用。
- Markdown 标题层级连续，表格、代码围栏、公式分隔符和 Mermaid 围栏闭合。
- 论文结论、代码证据、AI 推断和研究者决定没有混写。
- 字数、段落、公式、图表、实验表格和局限数量达到所选风格要求。
- 无“深入探讨”“至关重要”“值得注意的是”等空泛套话。
- Obsidian Wikilink 和本地附件引用没有明显断链。
- 若生成 HTML，再由 `$md-to-html` 完成桌面与 390px 移动端验证。

## 风格要求

### academic

- 中文正文不少于 4000 字、20 段。
- 论文公式不少于 5 处，每处附直观解释。
- Figure/Table 引用不少于 3 处。
- 实验数据表不少于 2 张。
- 有官方代码时给出不少于 2 段源码对应。
- 至少分析 2 处局限，其中至少 1 处来自作者自述。
- 结构：元信息 → 摘要 → 背景 → 预备知识 → 方法 → 实验 → 讨论 → 局限 → 结论。

### storytelling

- 正文不少于 3000 字、15 段，论文短引不少于 3 处。
- 至少 2 个恰当类比，结尾有可复述的收束句。
- 结构：钩子 → 瓶颈 → 核心洞察 → 方法 → 实验 → 意义 → 局限 → 回扣开头。

### concise

- 正文不少于 1200 字。
- 必须有 Mermaid 核心图、摘要 callout、核心数据表和收束句。
- 结构：核心图 → 五行摘要 → 3–5 个创新 → 数据表 → 局限 → 收束。

## 参考资源

- `styles/storytelling.md`
- `styles/academic.md`
- `styles/concise.md`
- `styles/with-formulas.md`
- `styles/with-code.md`

`scripts/generate_html.py` 仅为历史兼容文件，不得用于新工作流。HTML 发布统一交给 `$md-to-html`。
