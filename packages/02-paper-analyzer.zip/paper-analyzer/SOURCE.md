# 来源与打包信息

- Skill：paper-analyzer
- 日期：2026-09-27
- 来源：https://github.com/zsyggg/paper-craft-skills
- 许可：上游 README 声明 MIT；包内附 MIT 文本及来源记录，上游未提供独立 LICENSE 文件。

## 包内行为

本包保留本地技能内容和配套资源。
