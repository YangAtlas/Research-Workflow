# 来源与打包信息

- Skill：systems-paper-writing
- 日期：2026-09-27
- 来源：https://github.com/Orchestra-Research/AI-Research-SKILLs/tree/main/20-ml-paper-writing/systems-paper-writing
- 许可：MIT；包含上游 LICENSE。会议模板和随附文件保留其原有声明。

## 包内行为

本包保留本地技能内容和配套资源。
