# 来源与打包信息

- Skill：doc-coauthoring
- 日期：2026-09-27
- 来源：https://github.com/anthropics/skills/tree/main/skills/doc-coauthoring
- 许可：上游 README 将多项示例技能描述为 Apache-2.0；此技能目录未附独立许可，具体适用许可待核实。

## 包内行为

本包保留本地技能内容和配套资源。
