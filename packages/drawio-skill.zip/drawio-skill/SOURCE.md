# 来源与打包信息

- Skill：drawio-skill
- 日期：2026-09-27
- 来源：https://github.com/Agents365-ai/drawio-skill
- 许可：MIT；图形索引的 Apache-2.0 声明和许可随包保留。

## 包内行为

本包保留本地技能内容和配套资源。
