# 来源与打包信息

- Skill：humanizer
- 日期：2026-09-27
- 来源：https://github.com/blader/humanizer
- 许可：MIT；保留本地随附 LICENSE。

## 包内行为

本包保留本地技能内容和配套资源。
