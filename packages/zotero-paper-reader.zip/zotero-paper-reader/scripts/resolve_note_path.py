#!/usr/bin/env python3
"""Resolve a safe zy-research paper-note path without writing any files."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys


DEFAULT_AREA = "无线感知"


def sanitize_title(title: str) -> str:
    title = title.strip()
    title = title.replace("/", "／").replace("\\", "＼").replace(":", "：")
    title = re.sub(r"[\x00-\x1f]", "", title)
    title = re.sub(r"\s+", " ", title)
    title = title.rstrip(". ")
    if not title:
        raise ValueError("Title is empty after sanitization")
    return title[:180]


def resolve_area(areas_root: Path, requested: str) -> Path:
    candidates = [path for path in areas_root.iterdir() if path.is_dir()]
    exact = [path for path in candidates if path.name.casefold() == requested.casefold()]
    if len(exact) == 1:
        return exact[0]
    partial = [
        path
        for path in candidates
        if requested.casefold() in path.name.casefold()
        or path.name.casefold() in requested.casefold()
    ]
    if len(partial) == 1:
        return partial[0]
    available = ", ".join(sorted(path.name for path in candidates))
    raise ValueError(f"Area '{requested}' is not unique. Available areas: {available}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--vault", type=Path, required=True, help="Research vault root")
    parser.add_argument("--title", required=True)
    parser.add_argument("--area", default=DEFAULT_AREA)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    try:
        vault = args.vault.expanduser().resolve()
        areas_root = (vault / "20_Research-Areas").resolve()
        if not areas_root.is_dir():
            raise ValueError(f"Areas root not found: {areas_root}")

        area_dir = resolve_area(areas_root, args.area)
        notes_dir = (area_dir / "02_论文笔记").resolve()
        if areas_root not in notes_dir.parents:
            raise ValueError("Resolved note directory escaped the areas root")
        if not notes_dir.is_dir():
            raise ValueError(f"Paper-note directory not found: {notes_dir}")

        filename = sanitize_title(args.title) + ".md"
        note_path = notes_dir / filename
        result = {
            "area": area_dir.name,
            "directory": str(notes_dir),
            "note_path": str(note_path),
            "exists": note_path.exists(),
        }
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(note_path)
        return 0
    except (OSError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

