#!/usr/bin/env python3
"""Read-only Zotero item/PDF lookup with a safe SQLite snapshot fallback."""

from __future__ import annotations

import argparse
from contextlib import contextmanager
import json
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile
from typing import Iterator
from urllib.parse import unquote, urlparse


DEFAULT_ZOTERO_DIR = Path.home() / "Zotero"


@contextmanager
def zotero_snapshot(zotero_dir: Path) -> Iterator[Path]:
    source = zotero_dir / "zotero.sqlite"
    if not source.is_file():
        raise FileNotFoundError(f"Zotero database not found: {source}")
    with tempfile.TemporaryDirectory(prefix="zotero-paper-reader-") as temp:
        target_dir = Path(temp)
        target = target_dir / "zotero.sqlite"
        shutil.copy2(source, target)
        for suffix in ("-wal", "-shm"):
            sidecar = Path(str(source) + suffix)
            if sidecar.is_file():
                shutil.copy2(sidecar, Path(str(target) + suffix))
        yield target


def resolve_attachment_path(zotero_dir: Path, key: str, raw_path: str | None) -> Path | None:
    if not raw_path:
        return None
    if raw_path.startswith("storage:"):
        return zotero_dir / "storage" / key / raw_path.removeprefix("storage:")
    if raw_path.startswith("file://"):
        return Path(unquote(urlparse(raw_path).path))
    path = Path(raw_path).expanduser()
    return path if path.is_absolute() else None


def connect_read_only(database: Path) -> sqlite3.Connection:
    uri = f"{database.resolve().as_uri()}?mode=ro"
    connection = sqlite3.connect(uri, uri=True)
    connection.row_factory = sqlite3.Row
    return connection


def get_field_ids(connection: sqlite3.Connection) -> dict[str, int]:
    rows = connection.execute(
        "SELECT fieldID, fieldName FROM fieldsCombined "
        "WHERE fieldName IN ('title', 'DOI', 'date', 'publicationTitle', 'url', 'abstractNote')"
    )
    return {row["fieldName"]: row["fieldID"] for row in rows}


def field_value(connection: sqlite3.Connection, item_id: int, field_id: int | None) -> str | None:
    if field_id is None:
        return None
    row = connection.execute(
        "SELECT v.value FROM itemData d "
        "JOIN itemDataValues v ON v.valueID = d.valueID "
        "WHERE d.itemID = ? AND d.fieldID = ?",
        (item_id, field_id),
    ).fetchone()
    return row["value"] if row else None


def creators(connection: sqlite3.Connection, item_id: int) -> list[str]:
    rows = connection.execute(
        "SELECT c.firstName, c.lastName, c.fieldMode "
        "FROM itemCreators ic JOIN creators c ON c.creatorID = ic.creatorID "
        "WHERE ic.itemID = ? ORDER BY ic.orderIndex",
        (item_id,),
    )
    names = []
    for row in rows:
        if row["fieldMode"]:
            name = row["lastName"]
        else:
            name = " ".join(part for part in (row["firstName"], row["lastName"]) if part)
        if name:
            names.append(name)
    return names


def collections(connection: sqlite3.Connection, item_id: int) -> list[str]:
    rows = connection.execute(
        "SELECT c.collectionName FROM collectionItems ci "
        "JOIN collections c ON c.collectionID = ci.collectionID "
        "WHERE ci.itemID = ? ORDER BY c.collectionName",
        (item_id,),
    )
    return [row["collectionName"] for row in rows]


def attachments(connection: sqlite3.Connection, zotero_dir: Path, item_id: int) -> list[dict]:
    rows = connection.execute(
        "SELECT ai.key, ia.path, ia.contentType, ia.linkMode "
        "FROM itemAttachments ia JOIN items ai ON ai.itemID = ia.itemID "
        "WHERE ia.parentItemID = ? ORDER BY "
        "CASE WHEN ia.contentType = 'application/pdf' THEN 0 ELSE 1 END, ai.itemID",
        (item_id,),
    )
    result = []
    for row in rows:
        resolved = resolve_attachment_path(zotero_dir, row["key"], row["path"])
        result.append(
            {
                "key": row["key"],
                "content_type": row["contentType"],
                "link_mode": row["linkMode"],
                "raw_path": row["path"],
                "path": str(resolved) if resolved else None,
                "exists": bool(resolved and resolved.is_file()),
            }
        )
    return result


def candidate_items(connection: sqlite3.Connection) -> list[sqlite3.Row]:
    return connection.execute(
        "SELECT i.itemID, i.key, i.dateAdded, i.dateModified, t.typeName "
        "FROM items i JOIN itemTypes t ON t.itemTypeID = i.itemTypeID "
        "LEFT JOIN deletedItems d ON d.itemID = i.itemID "
        "LEFT JOIN itemAttachments a ON a.itemID = i.itemID "
        "LEFT JOIN itemNotes n ON n.itemID = i.itemID "
        "WHERE d.itemID IS NULL AND a.itemID IS NULL AND n.itemID IS NULL "
        "ORDER BY i.dateModified DESC"
    ).fetchall()


def normalize(value: str | None) -> str:
    return (value or "").casefold()


def lookup(zotero_dir: Path, query: str, collection_filter: str | None, limit: int) -> list[dict]:
    with zotero_snapshot(zotero_dir) as snapshot:
        with connect_read_only(snapshot) as connection:
            fields = get_field_ids(connection)
            needle = normalize(query)
            collection_needle = normalize(collection_filter)
            matches = []
            for row in candidate_items(connection):
                item_id = row["itemID"]
                title = field_value(connection, item_id, fields.get("title"))
                doi = field_value(connection, item_id, fields.get("DOI"))
                date = field_value(connection, item_id, fields.get("date"))
                author_names = creators(connection, item_id)
                collection_names = collections(connection, item_id)
                haystack = " ".join(
                    [row["key"], title or "", doi or "", date or "", *author_names, *collection_names]
                ).casefold()
                if needle and needle not in haystack:
                    continue
                if collection_needle and not any(
                    collection_needle in name.casefold() for name in collection_names
                ):
                    continue
                item_attachments = attachments(connection, zotero_dir, item_id)
                pdfs = [
                    attachment
                    for attachment in item_attachments
                    if attachment["content_type"] == "application/pdf"
                    or str(attachment["path"] or "").lower().endswith(".pdf")
                ]
                matches.append(
                    {
                        "key": row["key"],
                        "item_type": row["typeName"],
                        "title": title,
                        "authors": author_names,
                        "date": date,
                        "doi": doi,
                        "publication": field_value(
                            connection, item_id, fields.get("publicationTitle")
                        ),
                        "url": field_value(connection, item_id, fields.get("url")),
                        "abstract": field_value(connection, item_id, fields.get("abstractNote")),
                        "collections": collection_names,
                        "zotero_select": f"zotero://select/library/items/{row['key']}",
                        "pdf_attachments": pdfs,
                        "date_modified": row["dateModified"],
                    }
                )
                if len(matches) >= limit:
                    break
            return matches


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--query", required=True, help="Title, DOI, author, collection, or item key")
    parser.add_argument("--collection")
    parser.add_argument("--limit", type=int, default=8)
    parser.add_argument("--zotero-dir", type=Path, default=DEFAULT_ZOTERO_DIR)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.limit < 1 or args.limit > 50:
        parser.error("--limit must be between 1 and 50")

    try:
        results = lookup(args.zotero_dir.expanduser(), args.query, args.collection, args.limit)
        payload = {"query": args.query, "count": len(results), "results": results}
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            for item in results:
                author = item["authors"][0] if item["authors"] else "Unknown author"
                pdf_state = "PDF" if any(pdf["exists"] for pdf in item["pdf_attachments"]) else "no local PDF"
                print(f"{item['key']}\t{item['date'] or ''}\t{author}\t{pdf_state}\t{item['title']}")
        return 0 if results else 1
    except (FileNotFoundError, OSError, sqlite3.Error) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

