# ZY Research vault profile

## Paths

- Vault root: explicitly supplied by the user as `--vault <vault-root>`
- Areas root: `20_Research-Areas`
- Default area: `无线感知`
- Default paper-note directory: `20_Research-Areas/无线感知/02_论文笔记`
- Paper template: `00_Home/Templates/Paper.md`

## Routing

Use explicit user intent before all automatic routing.

For `无线感知`, strong signals include:

- WiFi sensing, wireless sensing, RF sensing, device-free sensing
- CSI sensing, CSI-Bench, activity recognition, localization, respiration, fall detection
- cross-device, cross-environment, cross-user, domain generalization for CSI
- ACF, CSI-ratio, BVP, Doppler, Fresnel-zone sensing

Do not route a paper to `无线感知` only because it mentions WiFi, CSI, 802.11, or wireless communication. CSI compression feedback, beamforming feedback, user grouping, MCS, EESM, and link adaptation may belong to a project or a future communications area rather than sensing. When no matching area exists and the note is project-specific, ask before creating a new area; otherwise use the user's requested/default area and label the mismatch in the note.

## Safety

- Treat `sensitivity: internal` and unpublished project material as local-only.
- Zotero metadata and attachment paths are personal research data. Do not expose the full library listing.
- Never read credential files while resolving Zotero configuration.

