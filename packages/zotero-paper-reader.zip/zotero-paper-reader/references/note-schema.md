# Evidence-based paper note schema

Use this structure unless an existing area note establishes a compatible stronger convention.

```markdown
---
type: paper
status: reading
area: <area>
project:
created: YYYY-MM-DD
updated: YYYY-MM-DD
authors:
published:
doi:
source: zotero
zotero_key:
zotero_select:
pdf_source:
keywords:
review_status: pending
---

# <Exact paper title>

## 一句话价值

## 三句摘要

1.
2.
3.

## 论文元信息与来源

## 研究问题与可证伪假设

## 方法与系统链路

## 关键公式与假设

## 实验设计

## 关键结果与证据

| 结论 | 证据位置 | 观察 | 证据强度 |
| --- | --- | --- | --- |

## 逐图逐表解读

### Figure <编号>：<简短主题>

- **位置**：Figure <编号>，PDF p. <页码>，Section <章节>
- **图的目的**：作者为什么放这张图，它回答什么问题
- **如何阅读**：图类型、横纵轴、单位、图例、颜色/线型/标记，以及 ↑/↓ 方向
- **分面说明**：
  - **(a)**：该面板展示的变量、设置与具体含义
  - **(b)**：该面板展示的变量、设置与具体含义
- **主要观察（Reported result）**：图中可以直接读出的趋势、差异或数值
- **作者结论（Paper statement）**：正文对该图的解释或用它支持的主张
- **解读与边界**：混杂因素、坐标尺度、误差线/方差、统计显著性、缺失对照等；额外解释标记为 **AI 推断（待复核）**

### Table <编号>：<简短主题>

- **位置**：Table <编号>，PDF p. <页码>，Section <章节>
- **表的目的**：比较对象、实验问题或汇总内容
- **如何阅读**：行组、列组、数据集/场景、指标定义与 ↑/↓ 方向、加粗/下划线/颜色含义
- **关键结果（Reported result）**：最重要的数值、排名、差值或趋势；保留必要的比较条件
- **作者结论（Paper statement）**：正文对该表的解释或用它支持的主张
- **解读与边界**：公平性、可比性、方差/显著性、缺失基线或设置差异；额外解释标记为 **AI 推断（待复核）**

按论文出现顺序，为主文和附录/补充材料中的每个编号 Figure/Table 分别重复以上条目。不可读、重复、纯示意或正文未讨论的项目也必须保留条目并明确说明。

## 局限性与失效边界

### 作者明确说明

### AI 推断（待复核）

## 可复现性

## 与当前研究的关系

## 可复用概念与相关工作

## 待核查问题

## 来源
```

## Evidence rules

- Put exact performance numbers only in `关键结果与证据`, with a Figure/Table/Section anchor.
- `逐图逐表解读` must cover every numbered Figure and Table in source order, including appendix/supplement items; use one entry per numbered item.
- For every figure, explain visual encodings and each labeled panel. For every table, explain row/column structure, metric definitions and directionality, and highlighting conventions.
- Exact values may be repeated in `逐图逐表解读` only when necessary to explain that item; retain the exact Figure/Table and page/section anchor.
- When a caption, label, cell, or panel is unreadable, say so explicitly and do not reconstruct it by guessing.
- Label interpretations that go beyond the text as `AI 推断（待复核）`.
- Do not add a `研究者决定` unless it is quoted or linked from a project decision log.
- Keep quotations short. Prefer paraphrase plus page/section anchors.
- Use `review_status: pending` until the researcher verifies the note.
