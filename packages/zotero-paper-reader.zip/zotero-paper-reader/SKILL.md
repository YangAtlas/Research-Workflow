---
name: zotero-paper-reader
description: Find a paper in Zotero, retrieve and read its attached PDF, produce an evidence-based Chinese research note, and save it into the matching zy-research area. Use when the user asks to 精读/阅读/整理 a Zotero paper, import a Zotero PDF into Obsidian notes, create a literature note, or file a paper under 无线感知 or another research area. Prefer a connected Zotero tool when available; otherwise use the bundled read-only local Zotero lookup script. Default to `20_Research-Areas/无线感知/02_论文笔记` only when no stronger routing signal exists.
---

# Zotero Paper Reader

Turn one Zotero item and its attached PDF into a traceable zy-research paper note. Optimize for research use, not for an HTML article or a generic summary.

## Required inputs

Accept any one of:

- Zotero item key or selection
- Exact or partial title
- DOI
- Zotero collection plus title keywords

Use the current zy-research workspace unless the user supplies another vault.

## Workflow

### 1. Load repository rules

Read:

1. `AGENTS.md`
2. `00_Home/使用指南.md`
3. The selected area's `00_Area.md`
4. A project's `00_Project.md` only when the note is explicitly project-scoped

Do not scan unrelated areas or projects.

### 2. Resolve the Zotero item

First search available tools for a Zotero connector. If present:

1. Search by item key, DOI, or title.
2. Fetch the parent item's metadata, collections, tags, notes, and PDF attachments.
3. Download or resolve the PDF to a local temporary path.

If no Zotero connector is available, run:

```bash
python scripts/zotero_lookup.py --query "<title, DOI, or key>" --json
```

Add `--collection "<name>"` when known. The script only reads a temporary snapshot of the local Zotero database.

Require a unique match. For ambiguous results, show the few candidates with title, year, first author, and key; do not guess.

### 3. Read the complete PDF

Use the PDF skill or equivalent PDF extraction/rendering tools. Read the complete paper, including appendix sections needed to understand datasets, baselines, implementation, and limitations.

Build a complete inventory of every numbered Figure and Table in the main paper and appendix/supplement. For each item, read its caption, the body text that introduces or discusses it, and any referenced experimental or methodological context. Visually inspect every figure and every table; render the relevant page or crop at higher resolution when labels, legends, cells, or multi-panel details are unclear. Do not infer visual content from the caption alone.

If the PDF is missing or unreadable, stop before drafting the note and report the exact missing attachment or parsing problem.

### 4. Analyze evidence

Use the paper-analyzer idea of full-text acquisition, method reconstruction, experiment analysis, code-state checking, and self-review, but produce a Markdown research note rather than a promotional HTML article.

Separate these evidence types:

- **Paper statement**: a claim explicitly made by the authors
- **Reported result**: a number or observation in a figure, table, or appendix
- **AI inference**: an interpretation not stated verbatim in the paper
- **Researcher decision**: only a decision already present in the vault or supplied by the user

Never turn an AI inference into a paper claim. Never invent citations, figure numbers, standard numbers, datasets, metrics, or performance values.

Analyze:

1. Research question and falsifiable hypothesis
2. One-sentence value and three-sentence summary
3. Method pipeline: input → representation → model/system → output
4. Key assumptions and the reason each component may work
5. Experimental protocol, split strategy, baselines, metrics, and compute/hardware
6. Main results with exact Figure/Table/Section anchors
7. Every numbered Figure and Table, including appendix/supplement items: purpose, how to read it, variables and settings, panel/row/column meanings, main observations, the claim it supports, and interpretation limits
8. Ablations and negative or missing evidence
9. Author-stated limitations and independent limitations
10. Reproducibility: code, data, configs, seeds, and missing artifacts
11. Relationship to the selected area and current project questions

For multi-panel figures, explain each labeled panel before synthesizing the whole figure. For tables, explain the comparison setup, row and column groups, metrics and directionality, highlighting conventions, and the most decision-relevant values or trends. Distinguish what the authors state from what the visual evidence supports and from AI inference. If an item is unreadable, missing, duplicated, purely illustrative, or not discussed in the text, still list it and state that limitation rather than silently omitting it.

Search the web or GitHub only when needed to verify a code repository or bibliographic fact. Do not upload internal PDFs or unpublished material to an external service.

### 5. Route the note

Read `references/vault-profile.md`.

Routing priority:

1. User-specified destination
2. Explicit area supplied in the request
3. Existing matching note or link in an area
4. Zotero collection mapped to an area
5. Semantic match against available `20_Research-Areas/*/00_Area.md`
6. Default area: `无线感知`

After choosing an area, run:

```bash
python scripts/resolve_note_path.py \
  --vault "<vault-root>" \
  --title "<paper title>" \
  --area "<area name>" \
  --json
```

Do not overwrite an existing note. If the returned path already exists, inspect it and add material only when the user requested an update; otherwise report the existing note.

### 6. Write the note

Read `references/note-schema.md` and follow it. Start from `00_Home/Templates/Paper.md` when present.

Requirements:

- Write under the chosen area's `02_论文笔记` directory.
- Set `review_status: pending`.
- Preserve the exact paper title, authors, year, DOI/URL, Zotero item key, and `zotero://select/...` link when available.
- Link the local PDF as a source path only when it is safe and useful.
- Use Obsidian-compatible Markdown, wikilinks, callouts, formulas, and citations.
- Use Mermaid only when it clarifies a method pipeline; keep node labels simple.
- Add a `逐图逐表解读` section that covers every numbered Figure and Table in source order, including appendix/supplement items. Follow the per-item fields in `references/note-schema.md`.
- Anchor each item to its exact Figure/Table number and PDF page or section when available. Do not merge multiple numbered items into one entry.
- Do not copy long passages from the paper.

### 7. Validate

Before finishing, verify:

- The output path is inside `20_Research-Areas/<area>/02_论文笔记`.
- The Markdown frontmatter is valid.
- The title, DOI, year, authors, and Figure/Table anchors agree with the source.
- Every performance number has an exact paper location.
- The figure/table inventory and the `逐图逐表解读` section contain the same numbered items, in source order, with no unexplained gaps.
- Every multi-panel figure has panel-level coverage, and every table states metric directionality when it is defined.
- AI inferences are labeled.
- Existing files and Obsidian links were not overwritten or broken.

Report the Zotero item used, PDF used, note path, unresolved questions, and items requiring human verification.
